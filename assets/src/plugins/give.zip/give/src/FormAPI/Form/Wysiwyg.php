<?php

namespace Give\FormAPI\Form;

class Wysiwyg extends Field
{
}
