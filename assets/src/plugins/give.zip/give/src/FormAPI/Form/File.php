<?php

namespace Give\FormAPI\Form;

class File extends Media
{
}
