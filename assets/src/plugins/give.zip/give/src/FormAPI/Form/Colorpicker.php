<?php

namespace Give\FormAPI\Form;

class Colorpicker extends Field
{
}
