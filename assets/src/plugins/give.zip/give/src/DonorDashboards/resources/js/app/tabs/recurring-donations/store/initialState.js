export const initialState = {
    subscriptions: null,
    querying: false,
    error: null,
};
