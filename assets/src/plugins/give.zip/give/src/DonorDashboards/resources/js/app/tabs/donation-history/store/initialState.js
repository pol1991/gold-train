export const initialState = {
    donations: null,
    querying: false,
    count: null,
    revenue: null,
    average: null,
    currency: null,
    error: null,
};
