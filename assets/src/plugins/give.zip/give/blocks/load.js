import './donation-form/index';
import './donation-form-grid/index';
import './donor-wall/index';

// Import multi-form goal block from Multi-Form Goals src
import '../src/MultiFormGoals/resources/js/blocks/multi-form-goal/index';

// Import progress bar block from Multi-Form Goals src
import '../src/MultiFormGoals/resources/js/blocks/progress-bar/index';
